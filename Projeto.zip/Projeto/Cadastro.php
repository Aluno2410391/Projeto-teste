<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet"href = "cadastro.css">
</head>
<body>
     <img src="Gemini_Generated_Image_ttm0vrttm0vrttm0.png" alt="Logo">
     <div class="cadastro">
    <label for="email" class="email-label">Digite seu e-mail:</label>
    <input id="email" type="email" class="email-input" placeholder="Seu e-mail">
    <label for="Senha" class="senha-label">Digite uma senha:</label>
    <input id="Senha" type="password" class="senha-input" placeholder="Sua senha">
    <label for="confirmar-senha" class="confirme-label">Confirme sua senha:</label>
    <input id="confirmar-senha" type="password" class="confirme-input" placeholder="Confirmar sua senha">
    <a href="Verify.html">
    <button class="casdastrar-agora">Cadastrar</button></a>
    </div>
     <footer class="direitos">
     <p>&copy; 2026 Vinil e Groove. Todos os direitos reservados.</p>
    </footer>
</body>
</html>